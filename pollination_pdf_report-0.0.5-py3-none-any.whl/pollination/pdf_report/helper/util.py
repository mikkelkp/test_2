"""Utility helper functions."""
from typing import Union

from reportlab.platypus import Flowable, Frame, Paragraph
from pollination.pdf_report.templates.pagetemplate import Container


UNITS_ABBREVIATIONS = {
    'Meters': 'm',
    'Millimeters': 'mm',
    'Feet': 'ft',
    'Inches': 'in',
    'Centimeters': 'cm'
}


def calculate_remaining_height(
    frame: Union[Frame, Container], content: list[Flowable],
    additional_content: list[Flowable] = None
) -> float:
    """Calculate remaining height of a Frame or Container.

    This function calculates the remaining height available in a given Frame or
    Container after accounting for the height of the current and additional
    content.

    Args:
        frame: A ReportLab Frame or Pollination PDF Container.
        content: A list of ReportLab Flowables. This is the content that is
            currently added to the Frame or Container.
        additional_content: A list of ReportLab Flowables. This can be content
            that will be added at a later stage.
    """
    content_height = []
    for flowable in content:
        flowable_height = flowable.wrap(frame.width, frame.height)[1]
        if isinstance(flowable, Paragraph):
            flowable_height += getattr(flowable.style, 'spaceBefore', 0)
            flowable_height += getattr(flowable.style, 'spaceAfter', 0)
        content_height.append(flowable_height)
    content_height = sum(content_height)

    additional_content_height = []
    if additional_content:
        for flowable in additional_content:
            flowable_height = flowable.wrap(frame.width, frame.height)[1]
            if isinstance(flowable, Paragraph):
                flowable_height += getattr(flowable.style, 'spaceBefore', 0)
                flowable_height += getattr(flowable.style, 'spaceAfter', 0)
            additional_content_height.append(flowable_height)
    additional_content_height = sum(additional_content_height)

    remaining_height = frame.height - content_height - additional_content_height

    return remaining_height
